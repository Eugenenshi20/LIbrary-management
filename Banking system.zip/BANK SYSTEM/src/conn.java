
import java.sql.PreparedStatement;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author KANEZA
 */
class conn {

    static PreparedStatement preparedStatement(String Querry) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

}
